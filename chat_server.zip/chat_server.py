from socket import *
import threading

class Server():
    def __init__(self):
        self.getSock()

    def sendMsg(self, msg):
        self.connectionSock.send(msg.encode('utf-8'))

    def getMsg(self):
        while True:
            try:
                msg = self.connectionSock.recv(1024)
                print("GET: " + msg.decode('utf-8'))
            except ConnectionResetError:
                self.getSock()

    def getSock(self):
        self.serverSock = socket(AF_INET, SOCK_STREAM)
        self.serverSock.bind(('', 6000))
        self.serverSock.listen(1)
        print("LISTENING")
        self.connectionSock, addr = self.serverSock.accept()
        print("ACCEPTED")

if __name__ == '__main__':
    sck = Server()
    receiver = threading.Thread(target = sck.getMsg, args = ())
    receiver.start()

    while True:
        try:
            sendData = input()
            sck.sendMsg(sendData)
        except KeyboardInterrupt:
            break

    print("SERVER 종료")
